<?php
return array(

###########payment confirmation#################

	'dont_miss_your_gb' => '千万不要错过你的背部奖励',
	'your_upline_is_now' => '你的赞助商是现在',
	'min_two_classes' => '类你上面。你必须始终低于你的上线最低2类地位得到回馈。现在你应该升级，所以你不会错过的回馈奖励，如果你的上线升级到下一节课。',
	'upgrade' => '升级',
	'to' => '至',
	'class' => '类',
	'member_slot' => '会员插槽',
	'potential' => '潜在',
	'bonus_entitlement' => '奖金和权利',
	'you_are_about_to_upgrade' => '你想升级',
	'account' => '帐户',
	'agree_to_upgrade' => '通过同意接受，你的护照将自动为这次升级中扣除。你有一个小时的升级届满前作出付款的比特币。请确保你有足够的BTC升级，因为没有退款护照允许.',
	'i_will_decide_later' => '我将在稍后决定',
	'accept' => '接受',

###########asssistant blade#################

	'agb' => '协助与回馈',
	'potential_member_assistant' => '潜在成员的助手',
	'potential_assistant_earning' => '可能的援助盈利',
	'amount_to_assist' => '量协助',
	'update_wallet' => '更新钱包',
	'wallet_address' => '钱包地址',
	'network_matrix' => '网络矩阵',
	'ur_network_class_progress' => '您的网络概述',
	'upgrade_to_not_miss_dg' => '你应该升级你的阶级地位，从您的DG不要错过援助',
	'receive_if_qualify' => '您会收到从DG援助应的阶级地位的资格，你',
	'payment_waiting_confirmation' => '付款等待确认书',
	'time_date' => '时间/日期',
	'user_class' => '用户类别',
	'confirmation' => '确认',
	'u_r_about_to_upgrade_account' => '您将要升级您的帐户。',
	'update_ur_bitcoin_Wallet' => '更新您的比特币钱包',
	'cancel' => '取消',

###########pagb history###############
	'history' => '历史',
	'date' => '日期',
	'payment_for' => '支付',
	'payment_type' => '付款方式',
	'payment_from' => '付款从',
	'payment_to' => '支付',
	'payment_details' => '付款详情',


);
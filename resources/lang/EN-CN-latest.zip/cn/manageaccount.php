<?php
return array(
    'manage_network_account'=>'管理网络帐户',
    'manage_account' => '管理帐户：',
    'member_since' =>  '会员日期',
    'back_to_network_list' => '返回网络列表',
    'agb' => '协助与回馈',
    'ph' => '提供帮助 (PH)',
    'pairing' => 'Flex 配对',
    'instruction' => '说明',
    'i_one' => '你可以帮助你的网络中，负责任的成员的帐户。您可以升级，代表成员的帮助下（ PH）或管理配对。',
    'i_two' => '要使用援助，并提供帮助（ PH） ，你将支付代表该用户的任何交易将扣除你的护照。',
    









);
<?php
return array(

###########payment confirmation#################

	'pls_make_bitcoin_payment' => '请让您在比特币付款',
	'address' => '地址',
	'amount' => '为数',
	'timeout' => '时间到',
	'waiting_for_payment' => '等待您的付款.',
	'redirect_page' => '这个页面将完成付款后，被引导',
	'cancel' => '关闭',

#########upgradeblade################
	'upgrade' => '升级',
	'to_upgrade_account' => '要升级您的帐户，您必须提供助理合格的成员。使用比特币作为下面的以下信息请您付款。您有1个小时内完成这一交易。',
	'bitcoin_qr' => '比特币QR',
	'try_in_five' => '请在5分钟内重试。',
	'instruction' => '说明',
	'i_one' => '请一小时内付款您的护照已被扣除。在规定的时间内传输失败比特币付款，则必须使用另一种新的Passport信贷，升级到下一个。',
	


);
<?php
return array(

###########passport#################

    'pls_make_bitcoin_payment'=>'请做你的比特币付款...',
    'address' => '地址',
    'amount' => '量',
    'waiting_for_your_payment' => '等待您的付款.',
    'redirect_page' => '在完成付款后，页面会自动重定向',
    'cancel' => '撤消',



###########passport insufficient#################

    'passport_required' => '您需要购买通行证',
    'action_not_allowed' => '操作不被允许',
    'pls_purchase_passport' => '为了升级类, 请购买通票. 点击购买通票继续',
    'purchase_passport' => '购买通行证',


#################passport blade#########################
    'commit_transaction' => '为了保证交易BitRegion ，你需要使用护照。',
    'balance_passport' => '平衡护照',
    'passport_price' => '护照价格',
    'qty_to_purchase' => '数量购买',
    'total_passport_price' => '护照总价',
    'discount' => '折扣',
    'total_discount' => '总折扣',
    'total_after_discount' => '总折扣后',
    'passport_transaction_history' => '护照交易历史',
    'time_date' => '时间/日期',
    'decription' => '描述',
    'debit' => '借方',
    'credit' => '信用',
    'information' => '信息',
    'passport_usage' => '护照使用:',
    'upgrade_status' => '使用升级阶级地位',
    'use_to_ph' => '为了提供援助（ PH ）',
    'behalf_network_members' => '您还可以使用护照升级或PH为你的下线',
    'bulk_purchase' => '大量采购',
    'payment_waiting_confirmation' => '付款等待确认书',
    'quantity' => '数量',
    'confirmation' => '确认',
    'wallet_address' => '钱包地址',
    

);
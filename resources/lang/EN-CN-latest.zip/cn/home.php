<?php
return array(
    'welcome'=>'欢迎!',
    'pls_upgrade_to_become_member' => '请升级成Immigrant为这个社会的正式成员.',
    'received_one_passport' => '您会收到1免费通行证',
    'receive_one_passport_info' => '由于社会的象征升值，这本护照可以用来启动急救（升级到移民类） ，并解锁更大的兴趣Bitregion功能的能力。',
    'provide_asssistance_now' => '现在提供援助',
    'dont_miss_gb' => '千万不要错过你的背部奖励',
    'your_upline_is_now' => '你的赞助商是现在',
    'class_above' => '级以上你。你必须始终小于你的担保人最低2类地位得到反馈。现在，你应该升级，让你不会错过返还奖励，如果你的赞助商升级到下一节课。',
    'upgrade_now' => '立即升级',
    'assistance_given' => '鉴于助理',
    'assistance_received' => '助理收到',
    'members' => '会员',
    'upgrade_to' => '升级到',
    'class' => '类',
    'member_slot' => '会员插槽',
    'potential' => '潜在',
    'bonus_entitlement' => '奖金与权利',
    'total_ph' => '总PH',
    'dividend' => '股利',
    'current_pairing' => '当前配对',
    'next_pair_in' => '接下来配对',
    'passport_referral' => '推荐护照',
    'passport_overriding' => '护照重写',
    'ph_capital' => 'PH资本',
    'ph_dividend' => 'PH股息',
    'ph_referral' => 'PH赞助商',
    'ph_overriding' => 'PH重写',
    'flex_pairing' => 'Flex 配对',
    'br_shares' => 'BR分享',
    'available_br_Shares' => '可用的 BR分享',







);
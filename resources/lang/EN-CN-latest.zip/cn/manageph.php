<?php
return array(

###########payment confirmation#################

	'activeph' => '活动PH',
	'pledge_new_ph' => '新质押PH',
	'date' => '日期',
	'ph' => 'PH',
	'filled' => '填充',
	'day' => '日',
	'percentage' => '%',
	'profit' => '利润',
	'taken' => '采取',
	'status' => '状态',
	'sender_address' => '发件人地址',
	'receiver_address' => '收货人地址',
	'value' => '值',
	'btc' => 'TC',
	'transaction_hash' => '交易哈希',
	'ended_ph' => 'PH结束',
	'pls_insert_amount_to_ph' => '请插入PH量',
	'up_to' => '至',
	'ph_allowed' => 'pH值的允许',
	'ph_from' => '从pH值',
	'itcoin' => 'itcoin',
	'amount_to_ph' => 'PH量',
	'cancel' => '取消',
	'passport_required' => '需要护照',
	'action_not_allowed' => '操作不被允许',
	'pls_purchase_passport' => '为了提供帮助（ PH） ，你需要购买一本护照。点击“购买一本护照”按钮继续。',
	'purchase_passport' => '购买护照',
	'release_ph' => '发布援助（ PH ）',
	'release_ph_to_brshare' => '您将要发布此PH值可用BR份额。',
	'amount_to_convert' => '转换',
	'confirm_release' => '确认发行',
	'you_are_about_to_ph_for' => '你会想提供帮助',
	'deduct_passport' => '通过同意接受，您的护照将被自动扣除为此提供援助。',
	'i_will_decide_later' => '我将在稍后决定',
	'accept' => '接受',


);
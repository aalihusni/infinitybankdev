<?php
return array(

###########payment confirmation#################

    'payment_confirmation'=>'付款确认',
    'sender_address' => '发件人地址',
    'receiver_address' => '收货人地址',
    'transaction_hash' => '交易哈希',
    'amount' => '为数',
    'waiting_for_confirmation' => '等待确认',
    'of' => '的',
    'redirect_page' => '这个页面将完成付款后，被引导',
    'close' => '关闭',
    

###########payment confirmation blade#################
	'waiting_for_payment_confirmation' => '等待付款确认.',
	'instruction' => '说明',
	'three_of_three' => '请等待确认3出3 ，完成您的交易完成之前。确认是基于比特币网络传播。',
	'network_fee' => '所有的交易将产生比特币的网络成本。',








);
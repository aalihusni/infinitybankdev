<?php
return array(
    'footer_copyright' => 'Made by a bunch of geeks for <span class="fa fa-bitcoin" style="color:#ffb629; font-size:18px;"></span> community.'
);
<?php
return array(

###########emails#################

    'emails'=>'电子邮件',
    'you_have_no_emails' => '你不必电子邮件.',
    'view_all_emails' => '查看所有邮件',


###########notification#################

    'notifications'=>'通知',
    'pls_verify_your_identity' => '证明你的身份!',
    'click_to_verify_now' => '点击这里立即验证',
    'pls_verify_photo' => '请验证您的照片!',
    'click_to_verify_photo' => '点击这里立即验证',
    'no_notification' => '无通知',


###########passport#################

    'passport' => '通行证',
    'br_share' => 'BR 共享',

###########BR SHARE#################

);
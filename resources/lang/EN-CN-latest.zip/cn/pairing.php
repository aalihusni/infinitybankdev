<?php
return array(

###########payment confirmation#################

	'flex_pairing' => 'Flex配对',
	'info_about_pairing' => '每月配对信息.',
	'next_pair_in' => '接下来的配对',
	'current_pairing' => '当前配对',
	'left' => '向左',
	'middle' => '中间',
	'right' => '向右',
	'pair_history' => '配对历史',
	'time_date' => '时间/日期',
	'description' => '描述',
	'debit' => '借记',
	'credit' => '信用',
	'instructions' => '说明',
	'instruction_info' => '灵活的配对像正常的二元匹配系统。在较弱的腿将被计为您每月的奖金。 BitRegion小腿中间可以传输之前或奖金计算留下的任何时间。',
	




);
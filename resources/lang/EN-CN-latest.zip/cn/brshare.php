<?php
return array(

    'br_Shares'=>'BR股份',
    'pr' => '护照推荐（ PR ）',
    'po' => '护照重写（ PO ）',
    'phc' => 'PH资本（ PHC）',
    'phd' => 'PH股息（ PHD ）',
    'phr' => '赞助商PH （ PHR ）',
    'pho' => 'PH重写（ PHO ）',
    'fp' =>  'Flex的配对（ FP ）',
    'your' => '您的',
    'btc_wallet_info' => 'itcoin 电子钱包信息',
    'update_wallet' => '更新钱包',
    'wallet_address' => '钱包地址',
    'gh' => '获得帮助（ GH ）',
    'brshare_transac' => 'BR股份交易',
    'datetime' => '日期时间',
    'type' => '类型',
    'debit' => '借方',
    'credit' => '信用',
    'balance' => '平衡',
    'update_your_bitcoin_wallet' => '更新您的比特币钱包',
    'cancel' => '取消',
    



);
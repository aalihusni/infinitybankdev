<?php
return array(

###########email#################

    'email' => '电子邮件',
    'show_menu' => '显示菜单',
    'hide_menu' => '隐藏菜单',
    'inbox' => '收件箱',
    'label' => '标签',



###########email view#################



###########email inbox#################

'all' => '所有',
'read' => '阅读',
'unread' => '未读',



);
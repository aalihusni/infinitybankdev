<?php
return array(
    'manage_network_account'=>'Manage Network Account',
    'manage_account' => 'Manage Account:',
    'member_since' =>  'Member since:',
    'back_to_network_list' => 'Back to Network List',
    'agb' => 'Assistance & Giveback',
    'ph' => 'Provide Help',
    'pairing' => 'Pairing',
    'instruction' => 'Instructions',
    'i_one' => 'You can help to manage member(s) under your network. You can either upgrade, provide help (PH) or manage pairing on behalf of that member.',
    'i_two' => 'To use assistance and provide help (PH), you will pay on behalf of this user and any transaction will deduct your passport.',
    









);
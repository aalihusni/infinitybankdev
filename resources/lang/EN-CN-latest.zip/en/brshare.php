<?php
return array(

    'br_Shares'=>'BR Shares',
    'pr' => 'Passport Referral (PR)',
    'po' => 'Passport Overiding (PO)',
    'phc' => 'PH Capital (PHC)',
    'phd' => 'PH Dividend (PHD)',
    'phr' => 'PH Referral (PHR)',
    'pho' => 'PH Overiding (PHO)',
    'fp' =>  'Flex Pairing (FP)',
    'your' => 'Your',
    'btc_wallet_info' => 'itcoin Wallet information',
    'update_wallet' => 'Update Wallet',
    'wallet_address' => 'Wallet Address',
    'gh' => 'Get Help (GH)',
    'brshare_transac' => 'BR Shares Transactions',
    'datetime' => 'Date/Time',
    'type' => 'Type',
    'debit' => 'Debit',
    'credit' => 'Credit',
    'balance' => 'Balance',
    'update_your_bitcoin_wallet' => 'Update your Bitcoin Wallet',
    'cancel' => 'Cancel',
    



);
<?php
return array(

###########payment confirmation#################

    'payment_confirmation'=>'Payment Confirmation',
    'sender_address' => 'Sender Address',
    'receiver_address' => 'Receiver Address',
    'transaction_hash' => 'Transaction Hash',
    'amount' => 'Amount',
    'waiting_for_confirmation' => 'Waiting for confirmation',
    'of' => 'of',
    'redirect_page' => 'This page will be automatically redirected after you complete your payment.',
    'close' => 'Close',
    



###########payment confirmation blade#################
	'waiting_for_payment_confirmation' => 'Waiting for payment confirmation.',
	'instruction' => 'Instructions',
	'three_of_three' => 'Please wait for the confirmation 3 out of 3 to complete before your transaction is completed. Confirmation is based on the bitcoin network propagation.',
	'network_fee' => 'All transaction will incur bitcoin network fees.',





);
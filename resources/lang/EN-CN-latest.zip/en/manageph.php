<?php
return array(

###########payment confirmation#################

	'activeph' => 'Active PH',
	'pledge_new_ph' => 'Pledge New PH',
	'date' => 'Date',
	'ph' => 'PH',
	'filled' => 'Filled',
	'day' => 'Day',
	'percentage' => '%',
	'profit' => 'Profit',
	'taken' => 'Taken',
	'status' => 'Status',
	'sender_address' => 'Sender Address',
	'receiver_address' => 'Receiver Address',
	'value' => 'Value',
	'btc' => 'TC',
	'transaction_hash' => 'Transaction Hash',
	'ended_ph' => 'Ended PH',
	'pls_insert_amount_to_ph' => 'Please insert amount to (PH)',
	'up_to' => 'up to ',
	'ph_allowed' => 'PH Allowed',
	'ph_from' => 'PH from',
	'itcoin' => 'itcoin',
	'amount_to_ph' => 'Amount to PH',
	'cancel' => 'Cancel',
	'passport_required' => 'Passport Required',
	'action_not_allowed' => 'Action not allowed',
	'pls_purchase_passport' => 'In order to provide help (PH), you need to purchase a passport. Click "Purchase Passport" button to continue.',
	'purchase_passport' => 'Purchase Passport',
	'release_ph' => 'Release Provide Help (PH)',
	'release_ph_to_brshare' => 'You are about to release this PH to available BR Share.',
	'amount_to_convert' => 'Amount to convert',
	'confirm_release' => 'Confirm Release',
	'you_are_about_to_ph_for' => 'You are about to Provide Help for',
	'deduct_passport' => 'By agreeing to accept, your Passport will be automatically deducted for this Provide Help.',
	'i_will_decide_later' => 'I will decide later',
	'accept' => 'Accept',


);
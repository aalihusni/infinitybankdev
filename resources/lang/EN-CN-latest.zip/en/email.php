<?php
return array(

###########email#################

    'email' => 'Email',
    'show_menu' => 'Show Menu',
    'hide_menu' => 'Hide Menu',
    'inbox' => 'Inbox',
    'label' => 'Labels',



###########email view#################



###########email inbox#################

'all' => 'All',
'read' => 'Read',
'unread' => 'Unread',



);
<?php
return array(

###########emails#################

    'emails'=>'Emails',
    'you_have_no_emails' => 'You have no emails.',
    'view_all_emails' => 'View All Emails',


###########notification#################

    'notifications'=>'Notification',
    'pls_verify_your_identity' => 'Please verify your identity!',
    'click_to_verify_now' => 'Click here to verify now',
    'pls_verify_photo' => 'Please verify your Photo!',
    'click_to_verify_photo' => 'Click here to verify now',
    'no_notification' => 'No notification',


###########passport#################

    'passport' => 'Passport',
    'br_share' => 'BR Share',

###########BR SHARE#################

);
<?php
return array(

###########payment confirmation#################

	'pls_make_bitcoin_payment' => 'Please make your BitCoin payment',
	'address' => 'Address',
	'amount' => 'Amount',
	'timeout' => 'Timeout',
	'waiting_for_payment' => 'Waiting for your payment.',
	'redirect_page' => 'This page will be automatically redirected after you complete your payment.',
	'cancel' => 'Cancel',

##########upgradeblade################
	'upgrade' => 'Upgrade',
	'to_upgrade_account' => 'To upgrade your account, you must provide assistant to qualified member. Please make your payment using Bitcoin as the following information below. You have 1 hour to complete this transaction.',
	'bitcoin_qr' => 'Bitcoin QR',
	'try_in_five' => 'Please try again in 5 minutes.',
	'instruction' => 'Instructions',
	'i_one' => 'Please make payment within ONE HOUR as your passport is already deducted. If you fail to transfer bitcoin payment within the stipulated time, you will have to use another Passport credit to make the upgrade next time.',
	


);
<?php
return array(

###########payment confirmation#################

	'flex_pairing' => 'Flex Pairing',
	'info_about_pairing' => 'Information about your monthly pairing.',
	'next_pair_in' => 'Next Pairing in',
	'current_pairing' => 'Current Pairing',
	'left' => 'Left',
	'middle' => 'Middle',
	'right' => 'Right',
	'pair_history' => 'Pairing History',
	'time_date' => 'Time/Date',
	'description' => 'Description',
	'debit' => 'Debit',
	'credit' => 'Credit',
	'instructions' => 'Instructions',
	'instruction_info' => 'The flex pairing works like the normal binary pairing system. The lower leg will be counted as your monthly bonus. BitRegion allows you to transfer the middle leg to either left or right anytime before the bonus is calculated.',
	




);
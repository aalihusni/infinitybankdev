<?php
return array(

###########payment confirmation#################

	'dont_miss_your_gb' => 'Dont miss your Give Back incentive',
	'your_upline_is_now' => 'Your upline is now',
	'min_two_classes' => 'classes above you. You must always be minimum 2 classes status below your upline to receive Give Back. You should upgrade now so you wont miss the Give Back incentive if your upline upgrade to the next class.',
	'upgrade' => 'Upgrade',
	'to' => 'to',
	'class' => 'Class',
	'member_slot' => 'Member Slot',
	'potential' => 'Potential',
	'bonus_entitlement' => 'Bonus & Entitlements',
	'you_are_about_to_upgrade' => 'You are about to Upgrade',
	'account' => 'account',
	'agree_to_upgrade' => 'By agreeing to accept, your Passport will be automatically deducted for this upgrade. You have ONE hour to make the payment in bitcoin before the upgrade expires. Please ensure you have sufficient BTC to upgrade as there is no refund for passport allowed.',
	'i_will_decide_later' => 'I will decide later',
	'accept' => 'Accept',


###########asssistant blade#################

	'agb' => 'Assistance & Give Back',
	'potential_member_assistant' => 'Potential Member Assistant',
	'potential_assistant_earning' => 'Potential Assistant Earning',
	'amount_to_assist' => 'Amount To Assist',
	'update_wallet' => 'Update Wallet',
	'wallet_address' => 'Wallet Address',
	'network_matrix' => 'Network Matrix',
	'ur_network_class_progress' => 'Your network classes progress',
	'upgrade_to_not_miss_dg' => 'You should upgrade your class status to not miss assistance from your DG',
	'receive_if_qualify' => 'You receive assistance from your DG should your class status qualifies you',
	'payment_waiting_confirmation' => 'Payment Waiting Confirmations',
	'time_date' => 'Time/Date',
	'user_class' => 'User Class',
	'confirmation' => 'Confirmations',
	'u_r_about_to_upgrade_account' => 'You are about to Upgrade your account.',
	'update_ur_bitcoin_Wallet' => 'Update your Bitcoin Wallet',
	'cancel' => 'cancel',

###########pagb history###############
	'history' => 'History',
	'date' => 'Date',
	'payment_for' => 'Payment For',
	'payment_type' => 'Payment Type',
	'payment_from' => 'Payment From',
	'payment_to' => 'Payment To',
	'payment_details' => 'Payment Details',

);